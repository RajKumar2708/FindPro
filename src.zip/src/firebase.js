// src/firebase.js
import { initializeApp } from "firebase/app";
import { getAuth, GoogleAuthProvider, signInWithPopup, signOut } from "firebase/auth";
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyBMnlHgZUWn-4Win-q2OT60VjdarRmxxAY",
  authDomain: "findpro-311d8.firebaseapp.com",
  projectId: "findpro-311d8",
  storageBucket: "findpro-311d8.firebasestorage.app",
  messagingSenderId: "186554173874",
  appId: "1:186554173874:web:63d19588e44d702f8dbcab"
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const provider = new GoogleAuthProvider();

export const loginWithGoogle = () => signInWithPopup(auth, provider);
export const logoutUser = () => signOut(auth);


export const db = getFirestore(app);