import React, { useState } from "react";
import axios from "axios";
import { useAuth } from "../context/AuthContext";

const JobProviderPage = () => {
  const { user, loginWithGoogle, logoutUser } = useAuth();
  const [formData, setFormData] = useState({ name: "", service: "", phone: "", location: "", availability: "", image: "" });
  const [preview, setPreview] = useState(null);
  const [showPopup, setShowPopup] = useState(false);
  const [uploading, setUploading] = useState(false);

  const handleChange = (e) => setFormData((prev) => ({ ...prev, [e.target.name]: e.target.value }));

  const handleImageChange = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setPreview(URL.createObjectURL(file));
    setUploading(true);
    const formDataImg = new FormData();
    formDataImg.append("image", file);

    try {
      const res = await axios.post(
        "https://api.imgbb.com/1/upload?key=61e5a2af8633af2e00d831e7e0b061b7",
        formDataImg
      );
      setFormData((prev) => ({ ...prev, image: res.data.data.url }));
    } catch {
      alert("Image upload failed. Please try again.");
    } finally {
      setUploading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!user) return;
    if (!formData.image) {
      alert("Please wait until the image is uploaded.");
      return;
    }
    try {
      await axios.post("https://6873afdfc75558e27354ef1e.mockapi.io/jobproviders", formData);
      setShowPopup(true);
      setFormData({ name: "", service: "", phone: "", location: "", availability: "", image: "" });
      setPreview(null);
    } catch {
      alert("Submission failed");
    }
  };

  return (
    <div className="min-h-screen bg-white flex flex-col items-center p-6 gap-8">
      {/* Heading + Login/Logout */}
      <div className="relative w-full max-w-4xl flex items-center justify-center">
  {/* Title centered */}
  <h1 className="text-3xl md:text-5xl font-bold text-blue-900 text-center flex-1">
    Provide Your <span className="text-orange-600">"Service"</span>
  </h1>

  {/* Login / User Menu aligned right */}
  <div className="absolute right-0">
    {user ? (
      <div className="relative group">
        <button className="px-4 py-2 bg-blue-600 text-white rounded-xl hover:bg-blue-700">
          {user.displayName}
        </button>
        <div className="absolute right-0 mt-2 bg-white shadow-lg rounded-lg border hidden group-hover:block">
          <button
            onClick={logoutUser}
            className="block w-full text-left px-4 py-2 hover:bg-gray-100"
          >
            Logout
          </button>
        </div>
      </div>
    ) : (
      <button
        onClick={loginWithGoogle}
        className="px-4 py-2 bg-orange-600 text-white rounded-xl hover:bg-orange-700"
      >
        Login
      </button>
    )}
  </div>
</div>


      {/* Not logged in message */}
      {!user && <p className="text-gray-700">Login to provide service</p>}

      {/* Form (only if logged in) */}
      {user && (
        <form onSubmit={handleSubmit} className="w-full max-w-md border border-gray-300 rounded-xl p-6 shadow-md flex flex-col gap-4">
          <input name="name" onChange={handleChange} value={formData.name} placeholder="Enter Name" className="w-full px-4 py-2 border rounded-xl" />
          <input name="service" onChange={handleChange} value={formData.service} placeholder="Enter Service" className="w-full px-4 py-2 border rounded-xl" />
          <input name="phone" onChange={handleChange} value={formData.phone} placeholder="Phone Number" className="w-full px-4 py-2 border rounded-xl" />

          <select name="location" onChange={handleChange} value={formData.location} className="w-full px-4 py-2 border rounded-xl">
            <option value="">Select Location</option>
            <option value="chennai">Chennai</option>
            <option value="madurai">Madurai</option>
            <option value="coimbatore">Coimbatore</option>
            <option value="trichy">Trichy</option>
            <option value="salem">Salem</option>
            <option value="dindigul">Dindigul</option>
          </select>

          <select name="availability" onChange={handleChange} value={formData.availability} className="w-full px-4 py-2 border rounded-xl">
            <option value="">Select Availability</option>
            <option value="weekday">Weekdays</option>
            <option value="weekend">Weekends</option>
            <option value="alltime">All Time</option>
          </select>

          <label className="flex items-center justify-center w-full border-2 border-dashed border-gray-400 rounded-xl p-4 cursor-pointer hover:border-blue-500">
            <input type="file" accept="image/*" onChange={handleImageChange} className="hidden" />
            <span className="text-gray-500">{uploading ? "Uploading..." : "Click to upload image"}</span>
          </label>

          {preview && <img src={preview} alt="Preview" className="w-full h-40 object-cover rounded-xl shadow" />}

          <button
            type="submit"
            disabled={uploading}
            className={`mt-2 py-2 rounded-xl text-white ${uploading ? "bg-gray-400 cursor-not-allowed" : "bg-blue-600 hover:bg-blue-700"}`}
          >
            {uploading ? "Uploading Image..." : "Submit"}
          </button>
        </form>
      )}

      {/* Success Popup */}
      {showPopup && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50">
          <div className="bg-white p-8 rounded-xl shadow-lg text-center">
            <h2 className="text-2xl font-bold text-green-600 mb-4">🎉 Service Posted!</h2>
            <button onClick={() => setShowPopup(false)} className="mt-4 px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">OK</button>
          </div>
        </div>
      )}
    </div>
  );
};

export default JobProviderPage;
