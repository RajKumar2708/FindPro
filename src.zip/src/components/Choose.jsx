import React from 'react';
import { motion } from 'framer-motion';
import { CiLocationOn } from "react-icons/ci";
import { LuMessagesSquare } from "react-icons/lu";
import { LiaRupeeSignSolid } from "react-icons/lia";
import logo from '../assets/LogoWoBG.png';
import { useInView } from 'react-intersection-observer';

const Choose = () => {
  const [refTitle, inViewTitle] = useInView({ triggerOnce: true, threshold: 0.3 });
  const [refCards, inViewCards] = useInView({ triggerOnce: true, threshold: 0.3 });
  const [refTrust, inViewTrust] = useInView({ triggerOnce: true, threshold: 0.3 });
  const cardData = [
    {
      icon: <motion.div whileHover={{ scale: 1.1 }} transition={{ type: "spring" }}><CiLocationOn size={120} color="#EA580C" /></motion.div>,
      title: "Find the Best Providers Nearby",
      description: "Easily search for service providers in your area, check ratings, and read real customer feedback before hiring."
    },
    {
      icon: <motion.div whileHover={{ scale: 1.1 }} transition={{ type: "spring" }}><LuMessagesSquare size={120} color="#EA580C" strokeWidth={1} /></motion.div>,
      title: "Direct Communication, No Middlemen",
      description: "Contact service providers instantly without any intermediaries, ensuring smooth, hassle-free interactions tailored to your needs."
    },
    {
      icon: <motion.div whileHover={{ scale: 1.1 }} transition={{ type: "spring" }}><LiaRupeeSignSolid size={120} color="#EA580C" className='scale-[0.9]' /></motion.div>,
      title: "0% Commission, 100% Freedom",
      description: "FindPro charges no commission, so you pay providers directly with no hidden fees or extra costs."
    }
  ];

  return (
    <div className='relative flex flex-col min-h-[100vh] p-10 pl-6 gap-4 '>


      {/* Title Section */}
      <motion.div 
        ref={refTitle}
        initial={{ opacity: 0, x: -100 }}  
        animate={inViewTitle ? { opacity: 1, x: 0 } : {}} 
        transition={{ duration: 0.8 }}
        className="flex flex-col items-start gap-4 z-10"
      >
        <h1 className='text-6xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-blue-900 to-orange-600'>
          Why Choose
        </h1>
        <img src={logo} className='w-[260px] h-auto' alt="Logo" />
      </motion.div>

      {/* Cards Section */}
      <motion.div 
        ref={refCards}
        initial={{ opacity: 0,y:50}} 
        animate={inViewCards ? { opacity: 1,y:0} : {}} 
        transition={{ duration: 0.8, delay: 0.3 }}
        className='flex flex-col justify-around items-center ml-6 mt-6 mb-10 gap-8 lg:flex-row md:flex-row z-10'
      >
        {cardData.map((item, index) => (
          <motion.div 
            key={index} 
            initial={{ opacity: 0}} 
            animate={inViewCards ? { opacity: 1} : {}} 
            transition={{ duration: 0.9, delay: 0.2 * index }}
            className='w-full max-w-[320px] bg-white rounded-2xl shadow-lg flex flex-col justify-between p-6 gap-2 items-center transition-transform duration-300 hover:scale-105 hover:shadow-2xl hover:border-t-4 hover:border-orange-500 min-h-[350px]'
          >
            {item.icon}
            <h3 className='text-xl text-[#1E3A8A] text-center font-bold'>{item.title}</h3>
            <p className='text-md font-light text-gray-600 text-center'>{item.description}</p>
          </motion.div>
        ))}
      </motion.div>

      {/* Trust Badge */}
      <motion.div 
      ref={refTrust}
      initial={{ opacity: 0 }} 
      animate={inViewTrust ? { opacity: 1} : {}} 
      transition={{ duration: 0.6, delay: 0.6}}
      className="text-center mt-6 text-sm text-gray-500 z-10">
        ⭐ Trusted by local users | ✅ 100% Verified Providers
      </motion.div>

    </div>
  );
};

export default Choose;