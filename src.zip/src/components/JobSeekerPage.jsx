import React, { useState, useEffect } from "react";
import { db } from "../firebase";
import { collection, getDocs, query, orderBy } from "firebase/firestore";

const JobSeekerPage = () => {
  const [services, setServices] = useState([]);
  const [filteredServices, setFilteredServices] = useState([]);
  const [searchText, setSearchText] = useState("");
  const [selectedLocation, setSelectedLocation] = useState("");

  // Fetch job providers from Firebase
  useEffect(() => {
    const fetchData = async () => {
      try {
        const q = query(collection(db, "services"), orderBy("createdAt", "desc"));
        const snap = await getDocs(q);
        const data = snap.docs.map((doc) => ({
          id: doc.id,
          ...doc.data(),
        }));
        setServices(data);
        setFilteredServices(data);
      } catch (error) {
        console.error("Error fetching services:", error);
      }
    };
    fetchData();
  }, []);

  // Filter function
  const handleFilter = () => {
    const filtered = services.filter(
      (service) =>
        service.service.toLowerCase().includes(searchText.toLowerCase()) &&
        (selectedLocation === "" ||
          service.location.toLowerCase() === selectedLocation.toLowerCase())
    );
    setFilteredServices(filtered);
  };

  // Auto filter on searchText or selectedLocation change
  useEffect(() => {
    handleFilter();
  }, [searchText, selectedLocation]);

  return (
    <div className="min-h-screen bg-white flex flex-col p-8 gap-8">
      <h1 className="text-5xl font-bold text-blue-900 text-center mb-8">
        Find a <span className="text-orange-600">‎"Service Provider"</span>
      </h1>

      {/* Search and Filter */}
      <div className="flex flex-col lg:items-center lg:justify-center gap-4 lg:flex-row">
        <div className="w-[75%] flex flex-row gap-0">
          <input
            type="text"
            placeholder="Search for services..."
            value={searchText}
            onChange={(e) => setSearchText(e.target.value)}
            className="flex-1 px-4 py-2 border border-gray-300 rounded-tl-xl rounded-bl-xl shadow-sm focus:outline-none"
          />
          <button
            onClick={handleFilter}
            className="px-6 py-2 bg-orange-600 text-white rounded-tr-xl rounded-br-xl hover:bg-orange-700"
          >
            Search
          </button>
        </div>
        <div className="w-[40%] lg:w-[20%]">
          <select
            value={selectedLocation}
            onChange={(e) => setSelectedLocation(e.target.value)}
            className="w-full px-4 py-2 border border-gray-300 rounded-xl shadow-sm focus:ring-1 focus:ring-blue-500"
          >
            <option value="">All Locations</option>
            <option value="chennai">Chennai</option>
            <option value="madurai">Madurai</option>
            <option value="coimbatore">Coimbatore</option>
            <option value="trichy">Trichy</option>
            <option value="salem">Salem</option>
            <option value="dindigul">Dindigul</option>
          </select>
        </div>
      </div>

      {/* Provider Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-8 mt-8">
        {filteredServices.map((provider) => (
          <div
            key={provider.id}
            className="flex flex-col items-center w-full max-w-sm h-full bg-white shadow-md rounded-2xl p-5 transition-transform duration-300 hover:scale-105 hover:shadow-xl border border-gray-100"
          >
            <img
              src={provider.image}
              alt={provider.name}
              className="w-28 h-28 rounded-full object-cover shadow mb-4"
            />
            <h2 className="text-2xl font-semibold text-blue-900 mb-2">
              {provider.name}
            </h2>

            <div className="flex gap-2 mb-4">
              <span className="bg-orange-100 text-orange-700 px-3 py-1 text-xs rounded-full capitalize">
                {provider.availability}
              </span>
              <span className="bg-blue-100 text-blue-700 px-3 py-1 text-xs rounded-full capitalize">
                {provider.location}
              </span>
            </div>

            <div className="w-full text-left text-sm text-gray-700 space-y-2">
              <div className="flex items-center gap-2">
                <span className="text-orange-600">🛠️</span>
                <span className="font-medium">Service:</span> {provider.service}
              </div>
              <div className="flex items-center gap-2">
                <span className="text-pink-600">📞</span>
                <span className="font-medium">Phone:</span> {provider.phone}
              </div>
            </div>

            <a
              href={`tel:${provider.phone}`}
              className="mt-5 px-4 py-2 bg-orange-600 text-white rounded-xl hover:bg-orange-700 transition"
            >
              Contact Now
            </a>
          </div>
        ))}
      </div>
    </div>
  );
};

export default JobSeekerPage;
