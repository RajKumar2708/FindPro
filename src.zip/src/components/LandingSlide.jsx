import React, { useState, useEffect } from "react";
import logo from "../assets/LogoWoBG.png";
import { motion } from "framer-motion";
import { FaAnglesDown } from "react-icons/fa6";
import Navbar from "./Navbar";

const text = "Discover and Connect with Trusted Local Professionals for All Your Needs!";

const LandingSlide = () => {
  const [showScrollIndicator, setShowScrollIndicator] = useState(true);

  useEffect(() => {
    const handleScroll = () => {
      setShowScrollIndicator(window.scrollY < window.innerHeight * 0.3);
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <>
      <motion.div
        initial={{ opacity: 0, y: -30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, delay: 1.5 }}
      >
        <Navbar />
      </motion.div>


      <div id="landing-page" className="relative flex flex-col items-center pt-36 h-screen w-full gap-8">
        

        <motion.img
          src={logo}
          className="lg:w-auto lg:h-[25%] w-[85%] h-[12%]"
          initial={{ opacity: 0, filter: "blur(10px)" }}
          animate={{ opacity: 1, filter: "blur(0px)" }}
          transition={{ duration: 1.2, ease: "easeOut" }}
        />

        <h1 className="text-lg lg:text-2xl text-transparent bg-clip-text bg-gradient-to-r from-blue-900 to-orange-600 font-bold [word-spacing:3px] text-center">
          <motion.span
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ staggerChildren: 0.05 }}
          >
            {text.split("").map((char, index) => (
              <motion.span
                key={index}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: index * 0.02 }}
              >
                {char}
              </motion.span>
            ))}
          </motion.span>
        </h1>


        {showScrollIndicator && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 10 }}
            transition={{ duration: 0.5,delay: 2.0 }}
            className="absolute flex flex-col w-[120px] h-[120px] text-gray-600 text-center justify-center items-center bottom-20 right-6 animate-pulse mb-8">
            Scroll Down For More Info
            <FaAnglesDown className="mt-2 text-xl animate-bounce" />
          </motion.div>
        )}
      </div>
    </>
  );
};

export default LandingSlide;
