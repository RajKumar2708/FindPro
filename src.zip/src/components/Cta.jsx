import React from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { useNavigate } from 'react-router-dom';
import { FaUserTie, FaUsers } from 'react-icons/fa';

const Cta = () => {
  const [refTitle, inViewTitle] = useInView({ triggerOnce: true, threshold: 0.3 });
  const [refBtn, inViewButton] = useInView({ triggerOnce: true, threshold: 0.3 });
  const navigate = useNavigate();

  const handleSeekClick = () => navigate('/jobseek');
  const handleProviderClick = () => navigate('/jobprovide');

  return (
    <div className="flex flex-col min-h-screen bg-transparent">
      {/* Center Content */}
      <div className="flex flex-col items-center justify-center flex-grow px-6 py-12">
        
        {/* Title */}
        <motion.div
          ref={refTitle}
          initial={{ opacity: 0, y: -50 }}
          animate={inViewTitle ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center"
        >
          <h1 className="text-4xl md:text-6xl font-bold text-blue-900">
            Join Us <span className="text-orange-600">Today!</span>
          </h1>
          <p className="text-gray-600 text-lg mt-4 max-w-xl mx-auto">
            Find the perfect job or the right talent — faster, easier, and smarter.
          </p>
        </motion.div>

        {/* Buttons */}
        <motion.div
          ref={refBtn}
          initial={{ opacity: 0, y: 50 }}
          animate={inViewButton ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="flex flex-col sm:flex-row gap-8 mt-12"
        >
          {/* Job Seeker */}
          <div
            onClick={handleSeekClick}
            className="group cursor-pointer bg-white border border-gray-200 rounded-2xl px-8 py-6 shadow-lg hover:shadow-2xl transition-all duration-300 w-64 text-center"
          >
            <div className="flex justify-center">
              <FaUsers className="text-blue-900 text-3xl group-hover:text-orange-500 transition" />
            </div>
            <h3 className="text-lg font-semibold text-blue-900 mt-4">Job Seeker</h3>
            <p className="text-gray-500 text-sm mt-1">Discover opportunities tailored for you.</p>
          </div>

          {/* Job Provider */}
          <div
            onClick={handleProviderClick}
            className="group cursor-pointer bg-white border border-gray-200 rounded-2xl px-8 py-6 shadow-lg hover:shadow-2xl transition-all duration-300 w-64 text-center"
          >
            <div className="flex justify-center">
              <FaUserTie className="text-blue-900 text-3xl group-hover:text-orange-500 transition" />
            </div>
            <h3 className="text-lg font-semibold text-blue-900 mt-4">Job Provider</h3>
            <p className="text-gray-500 text-sm mt-1">Find the right talent in just a few clicks.</p>
          </div>
        </motion.div>
      </div>

      {/* Footer */}
      <footer className="w-full bg-gray-100 text-center text-sm text-gray-600 py-4 border-t">
        © {new Date().getFullYear()} FindPro. All rights reserved.
      </footer>
    </div>
  );
};

export default Cta;
