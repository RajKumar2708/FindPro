import React, { useRef, useEffect } from "react";
import LandingSlide from "./LandingSlide";
import Choose from "./Choose";
import Service from "./Service";
import Cta from "./cta";

const HomePage = () => {
  const chooseRef = useRef(null);

  useEffect(() => {
    const observer = new IntersectionObserver(() => {}, { threshold: 0.5 });
    if (chooseRef.current) observer.observe(chooseRef.current);
    return () => observer.disconnect();
  }, []);

  return (
    <div className="h-screen overflow-y-scroll md:snap-y md:snap-mandatory scroll-smooth">
      {/* Section 1 */}
      <div className="snap-start h-screen relative">
        <LandingSlide />
      </div>

      {/* Section 2 */}
      <div ref={chooseRef} className="snap-start min-h-screen">
        <Choose />
      </div>

      {/* Section 3 */}
      <div className="snap-start min-h-screen">
        <Service />
      </div>

      {/* Section 4 */}
      <div className="snap-start min-h-screen">
        <Cta />
      </div>
    </div>
  );
};

export default HomePage;
