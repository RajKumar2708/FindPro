import React from 'react';
import { useAuth } from "../context/AuthContext";

const Navbar = () => {
  const { user, login, logout } = useAuth();

  return (
    <div className='h-[15vh] flex justify-end items-center px-4'>
      {!user ? (
        <button 
          onClick={login} 
          className='border border-gray-500 px-2 py-1 rounded-lg text-[#1E3A8A] text-sm'>
          Login / Signup
        </button>
      ) : (
        <div className='flex gap-3 items-center'>
          <span className='text-[#1E3A8A] text-sm'>Welcome, {user.name}</span>
          <button 
            onClick={logout} 
            className='border border-gray-500 px-2 py-1 rounded-lg text-[#1E3A8A] text-sm'>
            Logout
          </button>
        </div>
      )}
    </div>
  );
};

export default Navbar;
