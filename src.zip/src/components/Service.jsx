import React from 'react'
import { LuSearchCheck } from "react-icons/lu";
import { HiOutlineUserGroup } from "react-icons/hi";
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';

const Service = () => {
    const [refTitle, inViewTitle] = useInView({ triggerOnce: true, threshold: 0.3 });
    const [refCards, inViewCards] = useInView({ triggerOnce: true, threshold: 0.3 });

    const cardData = [
        {
            icon: <motion.div whileHover={{ scale: 1.1 }} transition={{ type: "spring" }}><LuSearchCheck size={120}color="#EA580C" strokeWidth={1} /></motion.div>,
          title: "For Job Seekers",
          description: "Discover verified job opportunities near you, connect directly with trusted service providers, explore ratings and reviews from past employers, and enjoy a transparent, commission-free experience with no middlemen involved."
        },
        {
          icon: <motion.div whileHover={{ scale: 1.1 }} transition={{ type: "spring" }}><HiOutlineUserGroup size={120} color="#EA580C" strokeWidth={1} /></motion.div>,
          title: "For Service Providers",
          description: "Easily post jobs, find verified professionals ready to work, communicate directly with applicants, and manage the hiring process on your terms without paying any commission or hidden charges."
        }
      ];
  return (
    <div className='min-h-screen pt-10 pl-4'>
        <motion.div 
        ref={refTitle}
        initial={{ opacity: 0, x: -100 }}  
        animate={inViewTitle ? { opacity: 1, x: 0 } : {}} 
        transition={{ duration: 0.8 }}
        className="flex flex-col items-center gap-4 z-10"
      >
        <h1 className='text-6xl font-bold text-blue-900'>
          What Do <span className='text-orange-600'>"We Do"</span>
        </h1>
      </motion.div>

      {/* Cards Section */}
      <motion.div 
        ref={refCards}
        initial={{ opacity: 0,y:50}} 
        animate={inViewCards ? { opacity: 1,y:0} : {}} 
        transition={{ duration: 0.8, delay: 0.3 }}
        className='flex flex-col justify-center items-center mt-16 mb-10 gap-24 lg:flex-row md:flex-row z-10'
      >
        {cardData.map((item, index) => (
          <motion.div 
            key={index} 
            initial={{ opacity: 0}} 
            animate={inViewCards ? { opacity: 1} : {}} 
            transition={{ duration: 0.9, delay: 0.2 * index }}
            className='w-full max-w-[320px] bg-white rounded-2xl shadow-lg flex flex-col justify-between p-6 gap-2 items-center transition-transform duration-300 hover:scale-105 hover:shadow-2xl hover:border-t-4 hover:border-orange-500 min-h-[350px]'
          >
            {item.icon}
            <h3 className='text-xl text-[#1E3A8A] text-center font-bold'>{item.title}</h3>
            <p className='text-md font-light text-gray-600 text-center'>{item.description}</p>
          </motion.div>
        ))}
      </motion.div>

    </div>
      
  )
}

export default Service
